#!/bin/bash

if [ -t 1 ]; then
  echo "Please redirect the output to a file to get the flag."
else
  echo "Congratulations! Here is your flag: FLAG{you_found_the_flag}"
fi
